function convertToFahrenheit(){
    let celcius=prompt("Enter your temperature:");
    let fahrenheit =celcius * 9/5 + 32;
    document.getElementById("result").innerHTML = fahrenheit;
}
