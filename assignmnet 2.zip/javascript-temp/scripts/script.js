console.log("script");

var userName="george";


userName="james";

console.log(userName);
var employeeName="Kory";
var employeeAge= 27;
var employee="USA";
var employee="55589076"
var employeeSalaryMonthly=20000
var employeeSalaryYearly= employeeSalaryMonthly*12;

let clientName = "john:"
let isActive = true;
let credit=1000;

const endPoint = "http://localhost/mystore";





document.write(
`

<h1>Employee Info</h1>
<p>Name: ${employeeName}</p>
<p>Age: ${employeeAge}</p
`
)