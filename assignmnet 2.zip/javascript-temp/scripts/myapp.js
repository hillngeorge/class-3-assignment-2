//DB information
let userDB = "samantha";
let passDB = "Test1234";

function login(){
//1)  get the username and passwordfrom the user using a prompt
let userName = prompt('Enter your username:');
let userPassword = prompt("Enter your password");
console.log(userName, userPassword);
//2)compare the passDB with the variable

if(userName === userDB && userPassword === passDB){
document.getElementById("notifications").innerHtml =
"<p>Welcome to the canvas </p>"
}
else{
    document.getElementById("notifications").innerHtml = "<p class='alert-error'>Invalid username or password</p>"
}
//3)display on the HTML welcome to the system or invalid credentials

}